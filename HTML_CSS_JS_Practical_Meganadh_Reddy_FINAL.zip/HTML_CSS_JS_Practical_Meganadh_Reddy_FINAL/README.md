# HTML, CSS & JavaScript Practical Programs

**Student Name:** Meganadh Reddy  
**Register / Roll Number:** 250200531  
**Class / Section:** 6  
**Subject:** HTML, CSS & JavaScript  
**Skills:** C Language • Python • Data Structures • HTML • CSS • JavaScript

## Assignment
Complete practical programs website containing the supplied HTML, CSS and JavaScript experiment lists.

## Counts
- HTML: 15
- CSS: 269
- JavaScript: 295
- Total listed entries: 579

> The JavaScript count includes the repeated/extended sections exactly as listed in the supplied assignment.

## Theme
A light-blue glassmorphism theme is used throughout the dashboard, program lists and individual program pages.

## Run
Open `index.html` in a browser. No build step is required.

## Structure
- `index.html` — main dashboard
- `html/index.html` — HTML program list
- `css/index.html` — CSS program list
- `javascript/index.html` — JavaScript program list
- `assets/` — shared assets
- Every experiment is a separate HTML file.

## Notes
Some experiments that normally require an external service use browser-safe demo data or public demonstration media. Internet-dependent experiments should be tested with an internet connection.
